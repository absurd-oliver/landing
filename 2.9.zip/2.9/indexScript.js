const countdown = document.getElementById("countdown");
const init = parseInt(countdown.textContent);
const spin = document.getElementById("spinner");

var n = Math.round(init);

function start() {
	let timer = setInterval(() => {
		n -= 1;
		update();
		if (n === 0) {
 			clearInterval(timer);
			spin.classList.remove("hidden");
			countdown.classList.add("hidden");
			window.location.href = 'pages/landing.html';
			
		}
	}, 1000);
}

function update() {
	countdown.textContent = `${n}`;
}

window.addEventListener("DOMContentLoaded", () => {
	update();
	start();
});