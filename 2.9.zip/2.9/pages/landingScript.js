const spin = document.getElementById("spinner");
const landingText = document.getElementById("landingText");

function loadIn(){
	setTimeout(() => {
		spin.classList.add("hidden");
	landingText.classList.remove("hidden");
	}, 500);
}


window.addEventListener("DOMContentLoaded", () => {
	loadIn();
});