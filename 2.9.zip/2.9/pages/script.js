function redirect (loc){
window.location.href = loc;
}